import os, sys
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import json, urllib.request, urllib.parse

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
WEBAPP_URL = os.environ.get("WEBAPP_URL", "").strip()
API = f"https://api.telegram.org/bot{BOT_TOKEN}"



def path(p):
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "webapp", p)


class H(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="text/html; charset=utf-8"):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        p = self.path.split("?")[0]
        if p in ("/", "/index.html", "/game"):
            with open(path("index.html"), "rb") as f:
                return self._send(200, f.read())
        if p == "/health":
            return self._send(200, "ok", "text/plain")
        # статические файлы (если появятся)
        safe = os.path.normpath(p.lstrip("/"))
        if ".." in safe:
            return self._send(404, "not found", "text/plain")
        full = os.path.join(os.path.dirname(os.path.abspath(__file__)), "webapp", safe)
        if os.path.isfile(full):
            with open(full, "rb") as f:
                return self._send(200, f.read())
        return self._send(404, "not found", "text/plain")

    def log_message(self, *a):
        pass


def send_message(chat_id, text, reply_markup=None):
    payload = {"chat_id": chat_id, "text": text, "parse_mode": "HTML",
               "disable_web_page_preview": True}
    if reply_markup:
        payload["reply_markup"] = reply_markup
    try:
        req = urllib.request.Request(
            f"{API}/sendMessage",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=15).read()
    except Exception as e:
        print("send error", e, flush=True)


def keyboard():
    if not WEBAPP_URL:
        return None
    return {"inline_keyboard": [[{"text": "🎮 Играть", "web_app": {"url": WEBAPP_URL}}]]}


def handle(update):
    msg = update.get("message") or update.get("edited_message")
    if not msg:
        return
    chat_id = msg["chat"]["id"]
    text = (msg.get("text") or "").strip()
    first = (msg.get("from") or {}).get("first_name") or "друг"

    if text.startswith("/start"):
        send_message(
            chat_id,
            f"Привет, {first}!\n\n<b>Поймай звёзды</b> — аркада прямо в Telegram.\n"
            "Ведите палец по экрану и собирайте золотые звёзды. Красные кометы отнимают жизнь.",
            keyboard(),
        )
    elif text.startswith("/play") or text.lower() in ("играть", "play"):
        if WEBAPP_URL:
            send_message(chat_id, "Открывайте — и поехали.", keyboard())
        else:
            send_message(chat_id, "Игра пока не подключена к адресу. Сообщу, когда будет готово.")
    elif text.startswith("/help"):
        send_message(chat_id, "/start — начать\n/play — открыть игру\n/help — помощь")
    else:
        send_message(chat_id, "Нажмите кнопку ниже 👇", keyboard())


def run_bot():
    offset = 0
    while True:
        try:
            qs = urllib.parse.urlencode({"timeout": 30, "offset": offset})
            with urllib.request.urlopen(f"{API}/getUpdates?{qs}", timeout=45) as r:
                data = json.loads(r.read().decode())
            for u in data.get("result", []):
                offset = u["update_id"] + 1
                handle(u)
        except Exception as e:
            print("poll error", e, flush=True)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8080"))
    srv = ThreadingHTTPServer(("0.0.0.0", port), H)
    import threading
    if BOT_TOKEN:
        threading.Thread(target=run_bot, daemon=True).start()
        print("bot polling started", flush=True)
    print(f"web on :{port}", flush=True)
    srv.serve_forever()
